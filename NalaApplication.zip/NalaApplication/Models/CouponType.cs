﻿namespace NalaApplication.Models
{
    public class CouponType
    {
    }
}