import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent {
}
