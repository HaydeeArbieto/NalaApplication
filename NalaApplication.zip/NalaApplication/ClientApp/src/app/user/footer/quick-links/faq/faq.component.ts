import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './faq.navbar.component.html',
  styleUrls: ['./faq.component.css'],
})
export class FaqComponent {
}
