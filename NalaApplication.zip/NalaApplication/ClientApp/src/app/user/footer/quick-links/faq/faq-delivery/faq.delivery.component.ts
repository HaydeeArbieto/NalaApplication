import { Component } from '@angular/core';

@Component({
  templateUrl: './faq.delivery.component.html',
  styleUrls: ['./faq.delivery.component.css'],
})
export class FaqDeliveryComponent { }
