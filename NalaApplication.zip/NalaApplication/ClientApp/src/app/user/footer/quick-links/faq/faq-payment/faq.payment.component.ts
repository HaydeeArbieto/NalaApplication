import { Component } from '@angular/core';

@Component({
  templateUrl: './faq.payment.component.html',
  styleUrls: ['./faq.payment.component.css'],
})
export class FaqPaymentComponent { }
