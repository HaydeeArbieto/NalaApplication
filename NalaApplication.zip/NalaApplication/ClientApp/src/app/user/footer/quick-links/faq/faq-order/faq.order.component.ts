import { Component } from '@angular/core';

@Component({
  templateUrl: './faq.order.component.html',
  styleUrls: ['./faq.order.component.css'],
})
export class FaqOrderComponent { }
