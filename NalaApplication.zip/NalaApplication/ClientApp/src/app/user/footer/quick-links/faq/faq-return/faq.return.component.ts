import { Component } from '@angular/core';

@Component({
  templateUrl: './faq.return.component.html',
  styleUrls: ['./faq.return.component.css'],
})
export class FaqReturnComponent { }
