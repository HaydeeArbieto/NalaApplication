import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './shipping-delivery.component.html',
  styleUrls: ['./shipping-delivery.component.css'],
})
export class ShippingComponent {
}
