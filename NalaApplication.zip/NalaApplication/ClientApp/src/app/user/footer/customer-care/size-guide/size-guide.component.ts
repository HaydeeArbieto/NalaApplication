import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './size-guide.component.html',
  styleUrls: ['./size-guide.component.css'],
})
export class SizeGuideComponent {
}
