import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './returns.component.html',
  styleUrls: ['./returns.component.css'],
})
export class ReturnsComponent {
}
