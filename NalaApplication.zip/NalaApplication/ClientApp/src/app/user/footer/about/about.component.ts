import { Component } from '@angular/core';

@Component({
  //selector: 'xxx',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css'],
})
export class AboutComponent {
}
