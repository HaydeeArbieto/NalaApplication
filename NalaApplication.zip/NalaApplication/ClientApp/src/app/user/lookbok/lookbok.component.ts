import { Component } from '@angular/core';

@Component({
  templateUrl: './lookbok.component.html',
  styleUrls: ['./lookbok.component.css'],
})
export class LookbokComponent {
}
