import { Component } from '@angular/core';

@Component({
  templateUrl: './payments-methods.component.html',
  styleUrls: ['./payments-methods.component.css'],
})
export class PaymentsMethodsComponent {
}
