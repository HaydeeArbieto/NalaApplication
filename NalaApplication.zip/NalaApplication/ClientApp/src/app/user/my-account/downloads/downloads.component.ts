import { Component } from '@angular/core';

@Component({
  templateUrl: './downloads.component.html',
  styleUrls: ['./downloads.component.css'],
})
export class DownloadsComponent {
}
