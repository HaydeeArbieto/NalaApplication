export class Product {
  Id : number;
  Name: string;
  Stock: string;
  Price: number;
  Description: string;
  PublishDate: Date;
  ImagePath: string;
  Color:string;
  Size: string;
  Raiting: number;
  Category: string;
   
}


